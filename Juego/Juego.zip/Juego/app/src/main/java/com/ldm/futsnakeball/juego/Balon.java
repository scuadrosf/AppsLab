package com.ldm.futsnakeball.juego;

public class Balon {
    public int x, y;

    public Balon(int x, int y) {
        this.x = x;
        this.y = y;
    }
}

