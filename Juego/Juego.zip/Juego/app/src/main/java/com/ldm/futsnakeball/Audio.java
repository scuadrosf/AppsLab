package com.ldm.futsnakeball;

public interface Audio {
    public Musica nuevaMusica(String nombreArchivo);
    public Sonido nuevoSonido(String nombreArchivo);
}
