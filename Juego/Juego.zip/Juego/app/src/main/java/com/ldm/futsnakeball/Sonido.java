package com.ldm.futsnakeball;

public interface Sonido {
    public void play(float volume);
    public void dispose();

    public void parar();
}

